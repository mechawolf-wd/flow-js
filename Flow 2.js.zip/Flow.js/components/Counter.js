export const Counter = () => ({
    template: `
        <div class="exampleClass">
            <expression>counter.value</expression> <br />
            <expression>computedValue.value</expression> <br />
            <button on:click="incrementCounter">Increment ++</button>
            <button on:click="decrementCounter">Decrement --</button>
        </div>
    `,
    script(Counter) {
        let counter = Counter.variable(0)

        let computedValue = Counter.observe(() => {
            return (counter.value + 1) * 10
        })

        const incrementCounter = () => {
            Counter.dispatchEvent('increment', { effect: () => { counter.value += 1 } })
        }

        const decrementCounter = () => {
            Counter.dispatchEvent('decrement', { effect: () => { counter.value -= 1 } })
        }

        return {
            counter,
            computedValue,
            incrementCounter,
            decrementCounter
        }
    }
})