import { Store } from '../store/Store.js'

export const Card = () => ({
    template: `
        <div class="exampleClass">
            <h3><expression>globalVariable.value</expression></h3>
            <p><expression>description</expression></p>
            <Counter on:increment="increment" on:decrement="decrement"></Counter>
            <input connect:placeholder="globalVariable.value" on:input="onInput" connect:value="globalVariable.value" />
        </div>
    `,
    script() {
        const increment = (payload) => payload.detail.effect()
        const decrement = (payload) => payload.detail.effect()

        const { globalVariable } = Store

        const onInput = (event) => {
            globalVariable.value = event.target.value
        }

        const title = 'Card Title'
        const description = 'This is a simple card example to demonstrate basic functionality. ' + Math.trunc(Math.random() * 100000)
        const details = 'More detailed information about the card can go here. This text is shown or hidden by clicking the "Show Details" button.'

        return {
            title,
            description,
            details,
            globalVariable,
            onInput,
            increment,
            decrement
        }
    }
})