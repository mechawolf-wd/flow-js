import { App } from './App.js'
import { Counter } from './components/Counter.js'
import { Card } from './components/Card.js'
import { Flow } from './node_modules/index.js'

Flow.connect(() => {
    Flow.mount(App)
    Flow.mount(Card)
    Flow.mount(Counter)
})