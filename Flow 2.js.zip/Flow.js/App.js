export const App = () => ({
    template: `
        <div class="exampleClass">
            <Card></Card>
        </div>
    `,
    script() { },
    style: {
        sheet: `
            .exampleClass {
                font-family: 'Times New Roman';
                color: teal;
                border: 1px solid grey;
                border-radius: 10px;
                padding: 20px;
                margin-bottom: 8px;
            }
        `
    }
})