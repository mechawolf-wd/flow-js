import { reactiveVariable } from '../node_modules/@flow/reactivity/reactiveVariable.js'

export const Store = {
    globalVariable: reactiveVariable('Bound Card title.')
}