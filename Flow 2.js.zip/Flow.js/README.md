# flow-js

# TODO

1. remove expression attribute from expression elements (not implemented)
2. add scoped styling (not implemented)

# WIP:

1. make a prop parser if it is a custom component
2. add connect:if directive
