import { variable } from './node_modules/@flow/reactivity/variable.js'

export const App = () => ({
    template: `
        <div class="exampleClass">
            <expression>counter.value ** 3</expression> <br />
            <button on:click="incrementCounter">Increment!</button>
            <Counter></Counter>
            <Counter></Counter>
        </div>
    `,
    setup() {
        let counter = variable(0)

        const incrementCounter = () => {
            counter.value += 1
        }

        // Static values

        const staticVariable = 'Counter raised to the power of'

        return {
            counter,
            staticVariable,
            incrementCounter
        }
    },
    style: {
        sheet: `
            .exampleClass {
                font-family: 'Times New Roman';
                color: teal;
            }
        `
    }
})