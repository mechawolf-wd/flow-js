import { variable } from '../node_modules/@flow/reactivity/variable.js'

export const Counter = () => ({
    template: `
        <div>
            <expression>staticVariable + ' 2:'</expression> <br />
            <expression>counter.value + counter.value</expression> <br />
            <button on:click="incrementCounter">Increment!</button>
        </div>
    `,
    setup() {
        let counter = variable(0)

        const incrementCounter = () => {
            counter.value += 1
        }

        // Static values

        const staticVariable = 'Counter raised to the power of'

        return {
            counter,
            staticVariable,
            incrementCounter
        }
    }
})